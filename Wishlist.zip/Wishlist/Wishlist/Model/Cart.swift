//
//  Cart.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.
//

import Foundation

struct Cart : Codable{
    var id : Int?
    var title : String?
    var brand : String?
    var price : String?
    var thumbnail : String?
    var type : String?
    
    
    init(id: Int? = nil, title: String? = nil, brand: String? = nil, price: String? = nil, thumbnail: String? = nil,type: String? = nil) {
        self.id = id
        self.title = title
        self.brand = brand
        self.price = price
        self.thumbnail = thumbnail
        self.type = type
    }
}
