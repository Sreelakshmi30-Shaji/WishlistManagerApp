//
//  ViewController.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    @IBOutlet weak var cartTableVIew: UITableView!
    
    @IBOutlet weak var cartSearchBar: UISearchBar!
    
    
    @IBOutlet weak var segmentControlOutlet: UISegmentedControl!
    
    var cartViewModel = CartViewModel()
    var cart = Cart()
    var items : [Cart] = []
    
    var dressItems : [Cart] = []
    var groceryItems : [Cart] = []
    var smartItems : [Cart] = []
    var lapItems : [Cart] = []
    var fragranceItems : [Cart] = []
    var homeItems : [Cart] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let nib = UINib(nibName: "CartTableViewCell", bundle: nil)
        cartTableVIew.register(nib, forCellReuseIdentifier: "cartTableViewCell")
        cartTableVIew.dataSource = self
        cartTableVIew.delegate = self
        
        cartSearchBar.delegate = self
        
        ///API Call
        cartViewModel.fetchApi { item, error in
            if error == nil{
                guard let item = item else{
                    return
                }
                self.items = item
                DispatchQueue.main.async {
                    self.cartTableVIew.reloadData()
                }
            }else{
                print("error")
            }
        }
    }
    

    
    @IBAction func segmentClick(_ sender: Any) {
        switch segmentControlOutlet.selectedSegmentIndex{
            
        case 0:
            DispatchQueue.main.async {
                self.cartTableVIew.reloadData()
            }
        case 1:
            dressItems.removeAll()
            for item in items {
                if item.type == "Dress"  {
                    dressItems.append(item)
                    var dressCount = dressItems.count
                       DispatchQueue.main.async {
                            self.cartTableVIew.reloadData()
                        }
                    }
                }
                
      case 2:
            groceryItems.removeAll()
            for item in items {
                if  item.type == "groceries" {
                    groceryItems.append(item)
                    var groceryCount = groceryItems.count
                        DispatchQueue.main.async {
                            self.cartTableVIew.reloadData()
                        }
                    }
                }
            
        case 3:
            smartItems.removeAll()
            for item in items {
                if  item.type == "SmartPhones" {
                    smartItems.append(item)
                    var  smartCount = smartItems.count
                    DispatchQueue.main.async {
                        self.cartTableVIew.reloadData()
                    }
                }
            }
            
        case 4:
            lapItems.removeAll()
            for item in items {
                if  item.type == "Laptop" {
                    lapItems.append(item)
                    var lapCount = lapItems.count
                    DispatchQueue.main.async {
                        self.cartTableVIew.reloadData()
                    }
                }
            }
            
        case 5:
            fragranceItems.removeAll()
            for item in items {
                if  item.type == "Fragrance" {
                    fragranceItems.append(item)
                    var fragranceCount = fragranceItems.count
                    DispatchQueue.main.async {
                        self.cartTableVIew.reloadData()
                    }
                }
            }
        case 6:
            homeItems.removeAll()
            for item in items {
                if  item.type == "home_decoration" {
                    homeItems.append(item)
                    var homeCount = homeItems.count
                    DispatchQueue.main.async {
                        self.cartTableVIew.reloadData()
                    }
                }
            }
            
        default:
            break
        }
    }
}


extension ViewController : UITableViewDataSource{
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch segmentControlOutlet.selectedSegmentIndex{
        case 0:
            return items.count
        case 1:
            return dressItems.count
        case 2:
            return groceryItems.count
        case 3:
            return smartItems.count
        case 4:
            return lapItems.count
        case 5:
            return fragranceItems.count
        case 6:
            return homeItems.count
        default:
            break
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = cartTableVIew.dequeueReusableCell(withIdentifier: "cartTableViewCell", for: indexPath) as! CartTableViewCell
        switch segmentControlOutlet.selectedSegmentIndex{
        case 0 :
            cell.cart = items[indexPath.row]
            cell.CartTitleLabel.text? = items[indexPath.row].title!
            cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
            cell.CartBrandLabel.text? = items[indexPath.row].brand!
            cell.CartPriceLabel.text? = items[indexPath.row].price!
            
            let imageUrl = URL(string: items[indexPath.row].thumbnail!)
            if let myImageUrl = imageUrl {
                do{
                    let imageData = try Data(contentsOf: myImageUrl)
                    cell.CartIMageView?.image = UIImage(data: imageData)
                }catch{
                    print("error")
                }
            }
            
        case 1:
            if dressItems.count > indexPath.row {
                cell.cart = dressItems[indexPath.row]
                cell.CartTitleLabel.text? = dressItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = dressItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = dressItems[indexPath.row].price!
                
                let imageUrl = URL(string: dressItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
       case 2:
            if groceryItems.count > indexPath.row {
                cell.cart = groceryItems[indexPath.row]
                cell.CartTitleLabel.text? = groceryItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = groceryItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = groceryItems[indexPath.row].price!
                
                let imageUrl = URL(string: groceryItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
        case 3:
            if smartItems.count > indexPath.row {
                cell.cart = smartItems[indexPath.row]
                cell.CartTitleLabel.text? = smartItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = smartItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = smartItems[indexPath.row].price!
                
                let imageUrl = URL(string: smartItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
        
        case 4:
            if lapItems.count > indexPath.row {
                cell.cart = lapItems[indexPath.row]
                cell.CartTitleLabel.text? = lapItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = lapItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = lapItems[indexPath.row].price!
                
                let imageUrl = URL(string: lapItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
        case 5:
            if fragranceItems.count > indexPath.row {
                cell.cart = fragranceItems[indexPath.row]
                cell.CartTitleLabel.text? = fragranceItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = fragranceItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = fragranceItems[indexPath.row].price!
                
                let imageUrl = URL(string: fragranceItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
        case 6:
            if homeItems.count > indexPath.row {
                cell.cart = homeItems[indexPath.row]
                cell.CartTitleLabel.text? = homeItems[indexPath.row].title!
                cell.CartTitleLabel.font = UIFont.boldSystemFont(ofSize: 16)
                cell.CartBrandLabel.text? = homeItems[indexPath.row].brand!
                cell.CartPriceLabel.text? = homeItems[indexPath.row].price!
                
                let imageUrl = URL(string: homeItems[indexPath.row].thumbnail!)
                if let myImageUrl = imageUrl {
                    do{
                        let imageData = try Data(contentsOf: myImageUrl)
                        cell.CartIMageView?.image = UIImage(data: imageData)
                    }catch{
                        print("error")
                    }
                }
            }
        default:
            break
    }
        return cell
    }
}


extension ViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(items[indexPath.row].title)
        print(items[indexPath.row].brand)
        print(items[indexPath.row].price)
        print(items[indexPath.row].thumbnail)
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(120)
    }
}
extension ViewController : UISearchDisplayDelegate,UISearchBarDelegate{
   
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
     
        if searchText.isEmpty {
            self.items = cartViewModel.items
            DispatchQueue.main.async {
                self.cartTableVIew.reloadData()
            }
        }else{
            cartViewModel.searchItem(searchText: searchText){success in
                if success{
                    self.items = cartViewModel.searchItms
                    print("success")
                }
                else{
                    //self.items = cartViewModel.items
                    self.items = []
                    print("error")
                }
                DispatchQueue.main.async {
                    self.cartTableVIew.reloadData()
                }
            }
       }
    }
}


