//
//  CartTableViewCell.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.
//

import UIKit


class CartTableViewCell: UITableViewCell {
    
    var cartViewModel = CartViewModel()
    var cart = Cart()
    var wishlist = Wishlist()
    
    
    
    
    @IBOutlet weak var itemAddButton: UIButton!
    
    
    @IBOutlet weak var itemDelButton: UIView!
    
    @IBOutlet weak var itemWishlistButton: UIButton!
    
    @IBOutlet weak var CartIMageView: UIImageView!
    
    @IBOutlet weak var CartTitleLabel: UILabel!
    
    @IBOutlet weak var CartBrandLabel: UILabel!
    
    
    @IBOutlet weak var CartPriceLabel: UILabel!
    
    
    @IBAction func addItem(_ sender: Any) {
        
        
        cartViewModel.addItemToCoreData(itemData: cart ){ success in
            if success {
                print("Item added to Core Data")
            } else {
                print("Failed to add item to Core Data")
            }
        }
    }
    
    @IBAction func removeItem(_ sender: Any) {
        
        cartViewModel.removeItemFromCoreData(item: cart){success in
            if success {
                print("Item removed from Core Data")
            } else {
                print("Failed to remove item from Core Data")
            }
        }
    }
    
    @IBAction func addWishlist(_ sender: Any) {
        
        cartViewModel.addItemToWishlist(itemData: cart){ success,status in
            if success{
                print("Item added to Wishlist")
            }else{
                print("Failed to add item to  wishlist")
            }
            if status{
                itemWishlistButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
            }
            else {
                itemWishlistButton.setImage(UIImage(systemName: "heart"), for: .normal)

            }
        }
}

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    
    }
}
