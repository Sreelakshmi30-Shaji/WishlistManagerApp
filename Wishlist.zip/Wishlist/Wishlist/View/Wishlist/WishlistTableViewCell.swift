//
//  WishlistTableViewCell.swift
//  Wishlist
//
//  Created by Sreelakshmi on 03/05/23.
//

import UIKit

class WishlistTableViewCell: UITableViewCell {
    
    var wishlist = Wishlist()
    
    @IBOutlet weak var WishlistImageView: UIImageView!
    
    @IBOutlet weak var WislistTitleLabel: UILabel!
    
    @IBOutlet weak var WishlistPriceLabel: UILabel!
    
    @IBOutlet weak var WishlistBrandLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
}
