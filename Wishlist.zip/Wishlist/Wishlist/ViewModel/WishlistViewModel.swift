//
//  WishlistViewModel.swift
//  Wishlist
//
//  Created by Sreelakshmi on 05/05/23.
//

import Foundation
import UIKit
import CoreData

class WishlistViewModel : NSManagedObject{
    
    var wishlistData : [Wishlist] = []
    
    func retrieveData(completion: @escaping ([Wishlist]?, Error?) -> Void) {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedObjectContext = appDelegate?.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WishlistItem")
        do{
            wishlistData = []
            let result = try managedObjectContext?.fetch(fetchRequest)
            if (result?.count)! > 0 {
                for data in result as! [NSManagedObject]{
                    var id = 0
                    var title = ""
                    var brand = ""
                    var price = ""
                    var thumbnail = ""
                    var type = ""
                    
                    if let dataId = data.value(forKey: "id") as? Int{
                        id = dataId
                    }
                    if let dataTitle = data.value(forKey: "title") as? String {
                        title = dataTitle
                    }
                    if let dataBrand = data.value(forKey: "brand") as? String {
                        brand = dataBrand
                    }
                    if let dataPrice = data.value(forKey: "price") as? String {
                        price = dataPrice
                    }
                    if let dataThumbnail = data.value(forKey: "thumbnail") as? String {
                        thumbnail = dataThumbnail
                    }
                    if let dataType = data.value(forKey: "type") as? String {
                        type = dataType
                    }
                    
                    wishlistData.append(Wishlist.init(id: id,title: title,brand: brand,price: price,thumbnail: thumbnail,type: type))
                }
                completion(wishlistData,nil)
            }
        }
        catch{
            completion(nil,error)
            print("Fetch Failed")
        }
        
    }
}
