//
//  CartViewModel.swift
//  Wishlist
//
//  Created by Sreelakshmi on 02/05/23.
//

import Foundation
import CoreData
import UIKit

class CartViewModel : NSManagedObject{
    
    var items:[Cart] = []
    var searchItms: [Cart] = []
    var cart = Cart()
    var view = ToastView()
    
    
    ///API Call
    func fetchApi(completion: @escaping ([Cart]?, Error?) -> Void) {
        let url = URL(string: "https://demo6641443.mockable.io/Wishlist")!
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                completion(nil, error)
                return
            }
            guard let data = data else {
                completion(nil, NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "No data received"]))
                return
            }
            do {
                let itemsList = try JSONDecoder().decode([Cart].self, from: data)
                self.items = itemsList
                completion(itemsList, nil)
            } catch let error {
                completion(nil, error)
            }
        }.resume()
    }
    
    /// Add Item To Core Data
    func addItemToCoreData(itemData: Cart, completion: (Bool) -> Void) {
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let cartEntity = NSEntityDescription.entity(forEntityName: "CartItem", in: managedObjectContext)!
        let item = NSManagedObject(entity: cartEntity, insertInto: managedObjectContext)
        item.setValue(itemData.id ?? 00, forKeyPath: "id")
        item.setValue(itemData.title ?? "", forKeyPath: "title")
        item.setValue(itemData.brand ?? "", forKeyPath: "brand")
        item.setValue(itemData.price ?? "", forKeyPath: "price")
        item.setValue(itemData.thumbnail ?? "", forKeyPath: "thumbnail")
        item.setValue(itemData.type ?? "", forKeyPath: "type")
        do {
            try managedObjectContext.save()
            completion(true)
        } catch let error as NSError {
            print("Error saving item to Core Data: \(error)")
        }
    }
    
    /// Retrieve Data From Core Data
    func retrieveData() {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let managedObjectContext = appDelegate?.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        do{
            let result = try managedObjectContext?.fetch(fetchRequest)
            if (result?.count)! > 0 {
                for data in result as! [NSManagedObject]{
                    print(data)
                    print(data.value(forKey: "id") as? Int)
                    print(data.value(forKey: "title") as? String)
                    print(data.value(forKey: "brand") as? String)
                    print(data.value(forKey: "price") as! String)
                    print(data.value(forKey: "thumbnail") as? String)
                    print(data.value(forKey: "type") as? String)

                }
            }
        }
        catch{
            print("Fetch Failed")
        }
    }
    
    /// Remove Item From Core Data
    func removeItemFromCoreData(item: Cart, completion: (Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
        if let itemiD = item.id {
            fetchRequest.predicate = NSPredicate(format: "id == %@", "\(itemiD)")
        }
        do{
            let objects = try managedObjectContext.fetch(fetchRequest)
            for object in objects {
                managedObjectContext.delete(object as! NSManagedObject)
                completion(true)
            }
            try managedObjectContext.save()
        }
        catch{
            print(error)
        }
    }
    
    /// Add Item To Wishlist and Remove from Wishlist
    func addItemToWishlist(itemData: Cart, completion: (Bool,_ status : Bool) -> Void) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedObjectContext = appDelegate.persistentContainer.viewContext
        guard let entityDescription = NSEntityDescription.entity(forEntityName: "WishlistItem", in: managedObjectContext) else {
            fatalError("Failed to retrieve entity description")
        }
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "WishlistItem")
        if let itemiD = itemData.id {
            fetchRequest.predicate = NSPredicate(format: "id == %@", "\(itemiD)")
        }
        do{
            let arrData = try managedObjectContext.fetch(fetchRequest)
            if arrData.count > 0 {
                print("Record already exist")
                for object in arrData {
                    managedObjectContext.delete(object as! NSManagedObject)
                }
                let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 250, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(toastView)
                toastView.show(message: "Item removed from Wishlist")
                completion(true,false)
            } else {
                let arrData = try managedObjectContext.fetch(fetchRequest)
                let item = NSManagedObject(entity: entityDescription, insertInto: managedObjectContext)
                item.setValue(itemData.id ?? 00, forKeyPath: "id")
                item.setValue(itemData.title ?? "", forKeyPath: "title")
                item.setValue(itemData.brand ?? "", forKeyPath: "brand")
                item.setValue(itemData.price ?? "", forKeyPath: "price")
                item.setValue(itemData.thumbnail ?? "", forKeyPath: "thumbnail")
                item.setValue(itemData.type ?? "", forKeyPath: "type")

                
                let toastView = ToastView(frame: CGRect(x: 100, y: 800, width: 200, height: 50))
                toastView.translatesAutoresizingMaskIntoConstraints = false
                view.addSubview(toastView)
                toastView.show(message: "Item added to Wishlist")
                completion(true,true)
            }
            try managedObjectContext.save()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    ///Search Item From Core Data
    func searchItem(searchText: String, completion: (Bool) -> Void) {
       
        var searchText : String = searchText
        if !searchText.isEmpty {
            
            let appDelegate = UIApplication.shared.delegate as? AppDelegate
            let managedObjectContext = appDelegate?.persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CartItem")
            fetchRequest.predicate = NSPredicate(format: "title CONTAINS [c] %@",searchText)
            do{
                searchItms = []
                let arrData = try managedObjectContext?.fetch(fetchRequest) as! [NSManagedObjectContext]
                if arrData.count > 0 {
                    print("Record already exist")
                    for data in arrData as! [NSManagedObject]{
                        var id = 0
                        var title = ""
                        var brand = ""
                        var price = ""
                        var thumbnail = ""
                        var type = ""

                        if let dataId = data.value(forKey: "id") as? Int{
                            id = dataId
                        }
                        if let dataTitle = data.value(forKey: "title") as? String {
                            title = dataTitle
                        }
                        if let dataBrand = data.value(forKey: "brand") as? String {
                            brand = dataBrand
                        }
                        if let dataPrice = data.value(forKey: "price") as? String {
                            price = dataPrice
                        }
                        if let dataThumbnail = data.value(forKey: "thumbnail") as? String {
                            thumbnail = dataThumbnail
                        }
                        if let dataType = data.value(forKey: "type") as? String {
                            type = dataType
                        }

                        searchItms.append(Cart.init(id: id,title: title,brand: brand,price: price,thumbnail: thumbnail,type: type))
                        completion(true)
                    }
                } else {
                    searchItms = items
                    completion(false)
                }
            } catch {
                print(error.localizedDescription)
            }
        }
     }
}
    
    
